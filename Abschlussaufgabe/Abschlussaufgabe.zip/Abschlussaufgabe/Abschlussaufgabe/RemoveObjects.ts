namespace Abschlussaufgabe {

    export class RemoveObjects {
        x: number;
        y: number;

        constructor(_x: number, _y: number) {
            this.x = _x;
            this.y = _y;
        }
        
        draw(): void {
            ;
        }
        
        remove(): void {
            ;
        }
        
    }
}