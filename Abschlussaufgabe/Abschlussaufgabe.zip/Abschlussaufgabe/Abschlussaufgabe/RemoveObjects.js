var Abschlussaufgabe;
(function (Abschlussaufgabe) {
    class RemoveObjects {
        constructor(_x, _y) {
            this.x = _x;
            this.y = _y;
        }
        draw() {
            ;
        }
        remove() {
            ;
        }
    }
    Abschlussaufgabe.RemoveObjects = RemoveObjects;
})(Abschlussaufgabe || (Abschlussaufgabe = {}));
//# sourceMappingURL=RemoveObjects.js.map